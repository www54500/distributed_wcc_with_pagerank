
package computation.seed_expansion;

import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

import computation.WccMasterCompute;
import vertex.WccVertexData;
import messages.PagerankPushMessage;
import aggregators.MergeCommunityAggregator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.BooleanWritable;
import org.apache.hadoop.io.MapWritable;

import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.graph.Vertex;
import org.apache.giraph.utils.MemoryUtils;

public class PersonailizedPageRankResult extends BasicComputation<IntWritable, WccVertexData, NullWritable, PagerankPushMessage> {
    public void preSuperstep() {}

    //TODO: Put in superclass
    @Override
    public void postSuperstep() {
      double freeMemory = MemoryUtils.freeMemoryMB()/1000; // Mem in gigs
      double freeNotInHeap = (MemoryUtils.maxMemoryMB() - MemoryUtils.totalMemoryMB())/1000;
      aggregate(WccMasterCompute.MIN_MEMORY_AVAILABLE, new DoubleWritable(freeMemory + freeNotInHeap));
    }

    @Override
    public void compute(Vertex<IntWritable, WccVertexData, NullWritable> vertex, Iterable<PagerankPushMessage> messages) {
        WccVertexData vData = vertex.getValue();
        MapWritable p = vData.getPagerank();
        MapWritable r = vData.getResidual();
        
        System.out.println(vertex.getId().get() + ":");
        /*Iterator it = p.entrySet().iterator();
        while (it.hasNext()){
        
        }*/
        
        ArrayList<Integer> communities = new ArrayList<Integer>();
        
        for (Map.Entry<Writable, Writable> e : p.entrySet()) {
            IntWritable srcId = (IntWritable) e.getKey();
            DoubleWritable pValue = (DoubleWritable) e.getValue();
            if (pValue.get() != 0.0) { System.out.println("p(" + srcId.get() + ") is " + pValue.get()); }
            communities.add(srcId.get());
        }
        
        //reduce("test", new IntWritable(3));
        /*System.out.println(" - - - - - - - - - - - - - - - ");
        for (Map.Entry<Writable, Writable> e : r.entrySet()) {
            IntWritable srcId = (IntWritable) e.getKey();
            DoubleWritable rValue = (DoubleWritable) e.getValue();
            if (rValue.get() != 0.0) { System.out.println("r(" + srcId.get() + ") is " + rValue.get()); }
        }*/
        System.out.println("");
        
        MapWritable MergeComm = new MapWritable();
        for (int i = 0; i < communities.size(); i++) {
            for (int j = i + 1; j < communities.size(); j++) {
                int communityKey = hashCode(communities.get(i), communities.get(j));
                MergeComm.put(new IntWritable(communityKey), new IntWritable(1));
            }
        }
        //MergeComm.put(new IntWritable(vData.getCommunity()), new CommunityAggregatorData(1, internalEdges, borderEdges));
        aggregate("mergeCommunity", MergeComm);
    }
    
    private int hashCode(int x, int y) {
        int a = Math.max(x, y);
        int b = Math.min(x, y);
        
        return a*31 + b;
    }
}
