
package vertex;

import messages.CommunityInitMessageArrayWritable;
import messages.CommunityInitializationMessage;
import computation.WccMasterCompute;
import utils.ArrayPrimitiveWritable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.MapWritable;

import java.lang.Math;

public class WccVertexData implements Writable {
    /**
     * The number of triangles x closes in the graph, i.e. t(x, V)
     */
    private int t;

    /**
     * The number of vertices that form at least one triangle with x, 
     * i.e. vt(x, V)
     */
    private int vt;

    private int communityT;

    private int communityVt;
   
    /**
     * The local clustering coefficient of x
     */
    private double clusteringCoefficient;
    
    private double localWcc;
    
    //private double pagerank;
    
    private MapWritable pagerank;
    
    //private double residual;
    
    private MapWritable residual;

    /**
     * The identifier of the community to which the vertex beints
     */
    private int community;
    
    private int previousCommunity;

    private int bestCommunity;

    private int bestSeedId;
    
    /**
     *  Used for community initialization phase
     */
    private CommunityInitMessageArrayWritable commInitNeighbors;

    /**
     *   A map from neighborId (IntWritable) to its community (IntWritable)
     */
    private MapWritable neighborCommunityMap;
    
    //private MapWritable countCommunityMap;

    /**
     *   An array containing the vertex's neighbors that have a higher degree.
     *   Used for preprocessing
     */
    private ArrayPrimitiveWritable higherDegreeNeighbors;

    /**
     *   An array containing the vertex's neighbors
     *   Used for preprocessing
     */
    private ArrayPrimitiveWritable neighbors;
    
    private ArrayPrimitiveWritable overlapCommunity;

    public WccVertexData () {
        t = vt = communityT = communityVt = 0;
        community = previousCommunity = bestCommunity = bestSeedId = WccMasterCompute.ISOLATED_COMMUNITY;
        commInitNeighbors = new CommunityInitMessageArrayWritable(new CommunityInitializationMessage[0]);
        neighborCommunityMap = new MapWritable();
        //countCommunityMap = new MapWritable();
        higherDegreeNeighbors = new ArrayPrimitiveWritable(new int[0]); 
        neighbors = new ArrayPrimitiveWritable(new int[0]);
        overlapCommunity = new ArrayPrimitiveWritable(new int[0]);
        localWcc = -1.0;
        pagerank = new MapWritable();
        residual = new MapWritable();
    }

    public int getT() { return t; }
    public int getVt() { return vt; }
    public int getCommunityT() { return communityT; }
    public int getCommunityVt() { return communityVt; }
    public double getClusteringCoefficient() { return clusteringCoefficient; }
    public double getLocalWcc() { return localWcc; }
    //public double getPagerank() { return pagerank; }
    public MapWritable getPagerank() { return pagerank; }
    //public double getResidual() { return residual; }
    public MapWritable getResidual() { return residual; }
    public int getCommunity() { return community; }
    public int getBestCommunity() { return bestCommunity; }
    public int getBestSeedId() { return bestSeedId; }
    
    public CommunityInitMessageArrayWritable getCommInitNeighbors() { 
        return commInitNeighbors;
    }

    public MapWritable getNeighborCommunityMap() { return neighborCommunityMap; }
    
    //public MapWritable getCountCommunityMap() { return countCommunityMap; }

    public ArrayPrimitiveWritable getHigherDegreeNeighbors() {
        return higherDegreeNeighbors;
    }

    public ArrayPrimitiveWritable getNeighbors() {
        return neighbors;
    }

    public ArrayPrimitiveWritable getOverlapCommunity() {
        return overlapCommunity;
    }
    
    public void updateCommunity(int c) { 
        this.previousCommunity = this.community;
        this.community = c; 
    }

    public void saveCurrentCommunityAsBest() {
        bestCommunity = community;
    }

    public void savePreviousCommunityAsBest() {
        bestCommunity = previousCommunity;
    }

    public void setT(int t) { this.t = t; }

    public void setVt(int vt) { this.vt = vt; }

    public void setCommunityT(int communityT) { this.communityT = communityT; }

    public void setCommunityVt(int communityVt) { this.communityVt = communityVt; }


    // TODO: SHOULD ONLY BE USED FOR TESTING
    public void setCommunity(int community) {
        this.community = community;
    }

    // TODO: SHOULD ONLY BE USED FOR TESTING
    public void setBestCommunity(int bestCommunity) {
        this.bestCommunity = bestCommunity;
    }

    public void setBestSeedId(int bestSeedId) {
        this.bestSeedId = bestSeedId;
    }

    public void setClusteringCoefficient(double cc) { 
        this.clusteringCoefficient = cc; 
    }
    
    public void setLocalWcc(double lwcc) { 
        this.localWcc = lwcc; 
    }
    
    //public void setPagerank(double p) { this.pagerank = p; }
    public void setPagerank(MapWritable p) { this.pagerank = p; }

    //public void setResidual(double r) { this.residual = r; }
    public void setResidual(MapWritable r) { this.residual = r; }
    
    public void setCommInitNeighbors(CommunityInitMessageArrayWritable sns) { 
        this.commInitNeighbors = sns; 
    }

    public void setNeighborCommunityMap(MapWritable ncm) { 
        this.neighborCommunityMap = ncm;
    }

    //public void setCountCommunityMap(MapWritable ccm) { 
    //    this.countCommunityMap = ccm;
    //}
    
    public void setHigherDegreeNeighbors(ArrayPrimitiveWritable hdns) {
        this.higherDegreeNeighbors = hdns;
    }

    public void setNeighbors(ArrayPrimitiveWritable ns) {
        this.neighbors = ns;
    }

    public void setOverlapCommunity(ArrayPrimitiveWritable oc) {
        this.overlapCommunity = oc;
    }
    @Override 
    public void readFields(DataInput input) throws IOException {
        t                       = input.readInt();
        vt                      = input.readInt();
        communityT              = input.readInt();
        communityVt             = input.readInt();
        clusteringCoefficient   = input.readDouble();
        localWcc                = input.readDouble();
        //pagerank                = input.readDouble();
        //residual                = input.readDouble();
        community               = input.readInt();
        previousCommunity       = input.readInt();
        bestCommunity           = input.readInt();
        bestSeedId              = input.readInt();
        pagerank.readFields(input);
        residual.readFields(input);
        commInitNeighbors.readFields(input);
        neighborCommunityMap.readFields(input);
        //countCommunityMap.readFields(input);
        higherDegreeNeighbors.readFields(input); 
        neighbors.readFields(input); 
        overlapCommunity.readFields(input);
    }

    @Override
    public void write(DataOutput output) throws IOException {
        output.writeInt(t);
        output.writeInt(vt);
        output.writeInt(communityT);
        output.writeInt(communityVt);
        output.writeDouble(clusteringCoefficient);
        output.writeDouble(localWcc);
        //output.writeDouble(pagerank);
        //output.writeDouble(residual);
        output.writeInt(community);
        output.writeInt(previousCommunity);
        output.writeInt(bestCommunity);
        output.writeInt(bestSeedId);
        commInitNeighbors.write(output); 
        neighborCommunityMap.write(output); 
        //countCommunityMap.write(output); 
        higherDegreeNeighbors.write(output);
        neighbors.write(output);
        overlapCommunity.write(output);
        pagerank.write(output);
        residual.write(output);
    }

    @Override
    public String toString() {
//        return "(t = " + t + ", vt = " + vt + ", clusteringCoefficient = " +
//            clusteringCoefficient + ", community = " + community + ", bestCommunity = " + bestCommunity + ")" ;
        return bestCommunity + "";
    }

//    @Override
//    public boolean equals(Object o) {
//        if (o instanceof WccVertexData) {
//            WccVertexData other = (WccVertexData) o;
//            double epsilon = 0.00000001;
//            return 
//                other.getT() == this.getT() &&
//                other.getVt() == this.getVt() &&
//                Math.abs(other.getClusteringCoefficient() -
//                        this.getClusteringCoefficient()) < epsilon  &&
//                other.getCommunity() == this.getCommunity();
//        }
//        return false;
//    }
//
    @Override
    public int hashCode() {
        return 31*t + 31*vt + 31*community; 
    }
}
