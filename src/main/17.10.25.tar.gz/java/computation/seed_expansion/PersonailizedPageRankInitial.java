
package computation.seed_expansion;

import computation.WccMasterCompute;
import vertex.WccVertexData;
import messages.CommunityCenterMessage;
import messages.PagerankPushMessage;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Writable;

import org.apache.giraph.graph.AbstractComputation;
import org.apache.giraph.graph.Vertex;
import org.apache.giraph.utils.MemoryUtils;

public class PersonailizedPageRankInitial extends AbstractComputation<IntWritable, WccVertexData, NullWritable, CommunityCenterMessage, PagerankPushMessage> {
    public void preSuperstep() {}

    //TODO: Put in superclass
    @Override
    public void postSuperstep() {
      double freeMemory = MemoryUtils.freeMemoryMB()/1000; // Mem in gigs
      double freeNotInHeap = (MemoryUtils.maxMemoryMB() - MemoryUtils.totalMemoryMB())/1000;
      aggregate(WccMasterCompute.MIN_MEMORY_AVAILABLE, new DoubleWritable(freeMemory + freeNotInHeap));
    }

    @Override
    public void compute(Vertex<IntWritable, WccVertexData, NullWritable> vertex, Iterable<CommunityCenterMessage> messages) {
        WccVertexData vData = vertex.getValue();
        int seedId = vData.getBestSeedId();
        int currentId = vertex.getId().get();
        double p = 0.0;
        double r = 0.0;
        int communityNumber = ((IntWritable) getAggregatedValue("communityNumber")).get();
        System.out.println("communityNumber: " + communityNumber);
        long degree = vertex.getNumEdges();
        double epsilon = 0.00001;
        double alpha = 0.99;

        if (seedId == currentId){
            r = (communityNumber == 0) ? 1.0 / 30.0 : 1.0/communityNumber;
            System.out.println(currentId + " is seed.");
        }
        
        //System.out.println(currentId + "'s r = " + r + " and epsilon * degree = " + epsilon * (double) degree);
        if (r > epsilon * (double) degree){
            double moving_probability = r - 0.5 * epsilon * (double) degree;
            r = 0.5 * epsilon * (double) degree;
            p += (1 - alpha) * moving_probability;
            double neighbor_update = alpha * moving_probability / (double) degree;
            //System.out.println(currentId + " send message");
            int[] src = new int[]{vertex.getId().get()};
            sendMessageToAllEdges(vertex, new PagerankPushMessage(src, new double[]{neighbor_update}));
        }
        
        updatePagerankMap(vertex, p);
        updateResidualMap(vertex, r);
    }
    
    private void updatePagerankMap(Vertex<IntWritable, WccVertexData, NullWritable> vertex, double pagerank) {
        WccVertexData vData = vertex.getValue();
        vData.getPagerank().put(vertex.getId(), new DoubleWritable(pagerank));
    }
    
    private void updateResidualMap(Vertex<IntWritable, WccVertexData, NullWritable> vertex, double residual) {
        WccVertexData vData = vertex.getValue();
        vData.getPagerank().put(vertex.getId(), new DoubleWritable(residual));
    }
}
