
package computation.seed_expansion;

import java.util.ArrayList;

import computation.WccMasterCompute;
import vertex.WccVertexData;
import messages.PagerankPushMessage;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.BooleanWritable;

import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.graph.Vertex;
import org.apache.giraph.utils.MemoryUtils;

public class PersonailizedPageRank extends BasicComputation<IntWritable, WccVertexData, NullWritable, PagerankPushMessage> {
    public void preSuperstep() {}

    //TODO: Put in superclass
    @Override
    public void postSuperstep() {
      double freeMemory = MemoryUtils.freeMemoryMB()/1000; // Mem in gigs
      double freeNotInHeap = (MemoryUtils.maxMemoryMB() - MemoryUtils.totalMemoryMB())/1000;
      aggregate(WccMasterCompute.MIN_MEMORY_AVAILABLE, new DoubleWritable(freeMemory + freeNotInHeap));
    }

    @Override
    public void compute(Vertex<IntWritable, WccVertexData, NullWritable> vertex, Iterable<PagerankPushMessage> messages) {
        WccVertexData vData = vertex.getValue();
        MapWritable pMap = vData.getPagerank();
        MapWritable rMap = vData.getResidual();
        double r_old = 0.0;
        double r_new = 0.0;
        double epsilon = 0.0001;
        double alpha = 0.99;
        long degree = vertex.getNumEdges();
        ArrayList<Double> pArray = new ArrayList<Double>();
        ArrayList<Double> rArray = new ArrayList<Double>();
        ArrayList<Integer> srcIdMsg = new ArrayList<Integer>();
        ArrayList<Double> neighborMsg = new ArrayList<Double>();
        ArrayList<Double> tmpR = new ArrayList<Double>();
        //System.out.println("PersonailizedPageRank(" + vertex.getId().get() + ")");
        
        // update neighbor residual
        for (PagerankPushMessage m : messages){
            int[] seedId = m.getSeedId();
            double[] neighbor_update = m.getNeighborUpdate();
            ArrayList<Integer> tmpSeed = new ArrayList<Integer>();
            //System.out.println("seedId.length = " + seedId.length);
            for (int i = 0; i < seedId.length; i++){
                //System.out.println(vertex.getId().get() + " get message from " + seedId[i]);
                r_old = (null == rMap.get(seedId[i])) ? 0.0 : ((DoubleWritable) rMap.get(seedId[i])).get();
                r_new = r_old + neighbor_update[i];
                //System.out.println("new r value = " + r_new);
                //System.out.println("epsilon * degree = " + epsilon * (double) degree);
                if (r_new > epsilon * (double) degree && r_old <= epsilon * (double) degree){
                    // need to push
                    srcIdMsg.add(seedId[i]);
                    tmpR.add(r_new);
                    //System.out.println(seedId[i] + " push the " + vertex.getId().get());
                }
                tmpSeed.add(seedId[i]);
                rArray.add(r_new);
            }
            updateResidual(vData, tmpSeed, rArray);
        }
        rArray.clear();
        
        // push
        if (srcIdMsg.size() != 0){
            //if (vertex.getId().get() == 3) { System.out.println(vertex.getId().get() + ":"); }
            for (int i = 0; i < srcIdMsg.size(); i++){
                int srcId = srcIdMsg.get(i);
                double p = (null == pMap.get(srcId)) ? 0.0 : ((DoubleWritable) pMap.get(srcId)).get();
                double r = tmpR.get(i);
                double moving_probability = r - 0.5 * epsilon * (double) degree;
                r = 0.5 * epsilon * (double) degree;
                p += (1 - alpha) * moving_probability;
                //if (vertex.getId().get() == 3) { System.out.println("p(" + srcId + ") is " + p); }
                double neighbor_update = alpha * moving_probability / (double) degree;
                neighborMsg.add(neighbor_update);
                pArray.add(p);
                rArray.add(r);
            }
            sendMessageToAllEdges(vertex, new PagerankPushMessage(srcIdMsg, neighborMsg));
            
            aggregate(WccMasterCompute.REPEAT_PHASE, new BooleanWritable(true));
        }
        
        //if (vertex.getId().get() == 3) { System.out.println("pArray = " + pArray.size() + "/ rArray = " + rArray.size() + "/ srcIdMsg = " + srcIdMsg.size()); }
        updatePagerank(vData, srcIdMsg, pArray);
        updateResidual(vData, srcIdMsg, rArray);
        /*
        if (srcIdMsg.size() != 0){
            double p = vData.getPagerank();
            double r = r_new;
            double moving_probability = r - 0.5 * epsilon * (double) degree;
            r = 0.5 * epsilon * (double) degree;
            p += (1 - alpha) * moving_probability;
            double neighbor_update = alpha * moving_probability / (double) degree;
            System.out.println("neighbor_update: " + neighbor_update);
            sendMessageToAllEdges(vertex, new CommunityCenterMessage(vertex.getId().get(), neighbor_update));
            vData.setPagerank(p);
            vData.setResidual(r);
            //System.out.println(vertex.getId().get() + ": p = " + p);
            //System.out.println(vertex.getId().get() + ": r = " + r);
            
            aggregate(WccMasterCompute.REPEAT_PHASE, new BooleanWritable(true));
        }
        */
    }
    
    private void updatePagerank(WccVertexData vData, ArrayList<Integer> seedId, ArrayList<Double> pagerankValue) {
        for (int i = 0; i < seedId.size(); i++){
            vData.getPagerank().put(new IntWritable(seedId.get(i)), new DoubleWritable(pagerankValue.get(i)));
        }
    }
    
    private void updateResidual(WccVertexData vData, ArrayList<Integer> seedId, ArrayList<Double> residualValue) {
        for (int i = 0; i < seedId.size(); i++){
            vData.getResidual().put(new IntWritable(seedId.get(i)), new DoubleWritable(residualValue.get(i)));
        }
    }
}
