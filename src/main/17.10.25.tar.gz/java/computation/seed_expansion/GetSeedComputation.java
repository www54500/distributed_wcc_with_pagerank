
package computation.seed_expansion;

import static computation.WccMasterCompute.ISOLATED_COMMUNITY;

import computation.WccMasterCompute;
import vertex.WccVertexData;
import messages.TransferMessage;
import messages.CommunityCenterMessage;
import aggregators.CommunityAggregatorData;
import utils.ArrayPrimitiveWritable;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.BooleanWritable;

import org.apache.giraph.graph.AbstractComputation;
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.graph.Vertex;
import org.apache.giraph.utils.MemoryUtils;

import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

public class GetSeedComputation extends AbstractComputation<IntWritable, WccVertexData, NullWritable, CommunityCenterMessage, CommunityCenterMessage> {

    private MapWritable commAggMap; 
    private double globalCC;

    public void preSuperstep() {
      commAggMap = getAggregatedValue(WccMasterCompute.COMMUNITY_AGGREGATES); 
      //globalCC = ((DoubleWritable) getAggregatedValue(WccMasterCompute.GRAPH_CLUSTERING_COEFFICIENT)).get() / getTotalNumVertices();
    }

    //TODO: Put in superclass
    @Override
    public void postSuperstep() {
      double freeMemory = MemoryUtils.freeMemoryMB()/1000; // Mem in gigs
      double freeNotInHeap = (MemoryUtils.maxMemoryMB() - MemoryUtils.totalMemoryMB())/1000;
      aggregate(WccMasterCompute.MIN_MEMORY_AVAILABLE, new DoubleWritable(freeMemory + freeNotInHeap));
    }

    /**
     * Compute new best community and notify neighbors if it is different
     * from the current community
     */
    @Override
    public void compute(Vertex<IntWritable, WccVertexData, NullWritable> vertex, Iterable<CommunityCenterMessage> messages) {
        int limitRound = ((IntWritable) getAggregatedValue("limitRound")).get();
        //System.out.println("limitRound: " + limitRound);
        WccVertexData vData = vertex.getValue();
        int community = vData.getCommunity();
        
        // check the best (largest) wcc value from neighbor and update, then info to the other neighbor
        int highestVertex = (vData.getBestSeedId() == -1) ? vertex.getId().get() : vData.getBestSeedId();
        double highestWcc = vData.getLocalWcc();
        boolean findNewHighest = (limitRound != 0) ? true : false;
        for (CommunityCenterMessage m : messages){
            int neighborId = m.getSourceId();
            //System.out.println(vertex.getId().get() + " get message from " + neighborId);
            double neighborWccValue = m.getWccValue();
            if (neighborWccValue > highestWcc){
                highestVertex = neighborId;
                highestWcc = neighborWccValue;
                vData.setLocalWcc(neighborWccValue);
                vData.setBestSeedId(neighborId);
                findNewHighest = true;
                //System.out.println(vertex.getId().get() + " find the new best wcc");
            } else if (neighborWccValue == highestWcc && neighborId > highestVertex){
                highestVertex = neighborId;
                findNewHighest = true;
                vData.setBestSeedId(neighborId);
                //System.out.println(vertex.getId().get() + " find the new best wcc");
            } else {
                //System.out.println(vertex.getId().get() + "do nothing.");
            }
        }
        
        // if find the new best wcc then repeat the process
        if (findNewHighest == true){
            aggregate(WccMasterCompute.REPEAT_PHASE, new BooleanWritable(true));
            MapWritable ncm = vertex.getValue().getNeighborCommunityMap();
            ArrayList<IntWritable> neighborId = new ArrayList<IntWritable>();
            for (Map.Entry<Writable, Writable> e : ncm.entrySet()) {
                IntWritable neighbor = (IntWritable) e.getKey();
                int neighborComm = ((IntWritable) e.getValue()).get();
                if (neighborComm == community){
                    //sendMessage(neighbor, new CommunityCenterMessage(highestVertex, highestWcc));
                    neighborId.add(neighbor);
                }
            }
            sendMessageToMultipleEdges(neighborId.iterator(), new CommunityCenterMessage(highestVertex, highestWcc));
        } else {
            vData.setLocalWcc(highestWcc);
            vData.setBestSeedId(highestVertex);
        }
    } 

    /**
     * Computes the local wcc value and sends it to an aggregator
     * 如果vertex不是獨立的，計算它的WCC
     */
    /*private double computeAndSendLocalWcc(Vertex<IntWritable, WccVertexData, NullWritable> vertex) {
        double localWCC = computeWcc(vertex);
        //aggregate(WccMasterCompute.WCC, new DoubleWritable(localWCC));
        return localWCC;
    }*/

    /**
     *  Computes a vertex's wcc with respect to its current community, using the
     *  adjacency lists of its neighbors within the community to count triangles
     * 計算“某點”的WCC
     */
    /*public double computeWcc(Vertex<IntWritable, WccVertexData, NullWritable> vertex) {
        WccVertexData vData = vertex.getValue();
        int globalT = vData.getT();
        int globalVt = vData.getVt();
        int communityT = vData.getCommunityT();
        int communityVt = vData.getCommunityVt();
        IntWritable community = new IntWritable(vData.getCommunity());
        CommunityAggregatorData commAggData = (CommunityAggregatorData) commAggMap.get(community);// 取得該Community的一些資訊
        int communitySize = commAggData.getSize(); 
        double rightDenom = (globalVt - communityVt + communitySize - 1); // WCC右邊的分母(|C\{x}|+vt(x,V\C))
        double wcc = (globalT == 0.0 || rightDenom == 0.0) ? 0.0 :  ((double) communityT/globalT) * ((double) globalVt / rightDenom);
        return wcc;
    }*/
}

