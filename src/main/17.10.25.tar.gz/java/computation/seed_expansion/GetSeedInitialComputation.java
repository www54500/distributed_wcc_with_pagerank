
package computation.seed_expansion;

import static computation.WccMasterCompute.ISOLATED_COMMUNITY;

import computation.WccMasterCompute;
import vertex.WccVertexData;
import messages.TransferMessage;
import messages.CommunityCenterMessage;
import aggregators.CommunityAggregatorData;
import utils.ArrayPrimitiveWritable;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.BooleanWritable;

import org.apache.giraph.graph.AbstractComputation;
import org.apache.giraph.graph.BasicComputation;
import org.apache.giraph.graph.Vertex;
import org.apache.giraph.utils.MemoryUtils;

import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;

public class GetSeedInitialComputation extends AbstractComputation<IntWritable, WccVertexData, NullWritable, ArrayPrimitiveWritable, CommunityCenterMessage> {

    private MapWritable commAggMap; 
    private double globalCC;

    public void preSuperstep() {
      commAggMap = getAggregatedValue(WccMasterCompute.COMMUNITY_AGGREGATES); 
      //globalCC = ((DoubleWritable) getAggregatedValue(WccMasterCompute.GRAPH_CLUSTERING_COEFFICIENT)).get() / getTotalNumVertices();
    }

    //TODO: Put in superclass
    @Override
    public void postSuperstep() {
      double freeMemory = MemoryUtils.freeMemoryMB()/1000; // Mem in gigs
      double freeNotInHeap = (MemoryUtils.maxMemoryMB() - MemoryUtils.totalMemoryMB())/1000;
      aggregate(WccMasterCompute.MIN_MEMORY_AVAILABLE, new DoubleWritable(freeMemory + freeNotInHeap));
    }

    /**
     * Compute new best community and notify neighbors if it is different
     * from the current community
     */
    @Override
    public void compute(Vertex<IntWritable, WccVertexData, NullWritable> vertex, Iterable<ArrayPrimitiveWritable> messages) {
        WccVertexData vData = vertex.getValue();
        /*double wccValue = 0.0;
        int community = vData.getCommunity();
        if (vData.getLocalWcc() == -1.0){
            wccValue = computeAndSendLocalWcc(vertex);
            vData.setLocalWcc(wccValue);
        } else {
            wccValue = vData.getLocalWcc();
        }*/
        double wccValue = vData.getLocalWcc();
        int community = vData.getCommunity();

        // sends wcc value to the same community neighbor
        MapWritable ncm = vertex.getValue().getNeighborCommunityMap();
        for (Map.Entry<Writable, Writable> e : ncm.entrySet()) {
            IntWritable neighborId = (IntWritable) e.getKey();
            int neighborComm = ((IntWritable) e.getValue()).get();
            if (neighborComm == community){
                sendMessage(neighborId, new CommunityCenterMessage(vertex.getId().get(), wccValue));
            }
        }
        // select any phase we want
        aggregate(WccMasterCompute.PHASE_OVERRIDE, new BooleanWritable(true));
        aggregate(WccMasterCompute.NEXT_PHASE, new IntWritable(WccMasterCompute.FIND_COMMUNITY_SEED));
        // next phase compute recursively
        aggregate(WccMasterCompute.REPEAT_PHASE, new BooleanWritable(true));
        // check the best (largest) wcc value from neighbor and update, then info the other neighbor
        /*int highestVertex = vertex.getId().get();
        double highestWcc = wccValue;
        boolean findNewHighest = false;
        for (CommunityCenterMessage m : messages){
            int neighborId = m.getSourceId();
            double neighborWccValue = m.getWccValue();
            if (neighborWccValue > highestWcc){
                highestVertex = neighborId;
                highestWcc = neighborWccValue;
                findNewHighest = true;
                System.out.println("find the new best wcc: " + highestWcc + ", it's " + highestVertex);
            }else if (neighborWccValue == highestWcc && neighborId > highestVertex){
                highestVertex = neighborId;
                findNewHighest = true;
                System.out.println("find the equal best wcc: " + highestWcc + ", and its id larger, it's " + highestVertex);
            }
        }*/
        
        // if find the new best wcc then repeat the process
        //if (findNewHighest == true){aggregate(WccMasterCompute.REPEAT_PHASE, new BooleanWritable(true));}
    } 

    /**
     * Computes the local wcc value and sends it to an aggregator
     * 如果vertex不是獨立的，計算它的WCC
     */
    /*private double computeAndSendLocalWcc(Vertex<IntWritable, WccVertexData, NullWritable> vertex) {
        double localWCC = computeWcc(vertex);
        //aggregate(WccMasterCompute.WCC, new DoubleWritable(localWCC));
        return localWCC;
    }*/

    /**
     *  Computes a vertex's wcc with respect to its current community, using the
     *  adjacency lists of its neighbors within the community to count triangles
     * 計算“某點”的WCC
     */
    /*public double computeWcc(Vertex<IntWritable, WccVertexData, NullWritable> vertex) {
        WccVertexData vData = vertex.getValue();
        int globalT = vData.getT();
        int globalVt = vData.getVt();
        int communityT = vData.getCommunityT();
        int communityVt = vData.getCommunityVt();
        IntWritable community = new IntWritable(vData.getCommunity());
        CommunityAggregatorData commAggData = (CommunityAggregatorData) commAggMap.get(community);// 取得該Community的一些資訊
        int communitySize = commAggData.getSize(); 
        double rightDenom = (globalVt - communityVt + communitySize - 1); // WCC右邊的分母(|C\{x}|+vt(x,V\C))
        double wcc = (globalT == 0.0 || rightDenom == 0.0) ? 0.0 :  ((double) communityT/globalT) * ((double) globalVt / rightDenom);
        return wcc;
    }*/
}

